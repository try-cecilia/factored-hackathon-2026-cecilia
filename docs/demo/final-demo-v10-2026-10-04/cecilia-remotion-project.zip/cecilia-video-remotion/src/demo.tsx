import React from "react";
import {
  AbsoluteFill,
  OffthreadVideo,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";
import { B, F, clamp, easeInOut, ramp } from "./brand";
import { cue, type Scene } from "./cues";

type Plan = {
  keys: number[];
  scale: number[];
  cx: number[];
  cy: number[];
  titles: { at: number; text: string }[];
};

// Native 3840 × 2400 Chrome captures use a 1920 × 1200 CSS viewport.
// Size footage directly at the camera dimensions to avoid an extra scaled layer.
// Results, receipts and operator state stay unobstructed throughout each shot.
const plans = (): Record<string, Plan> => ({
  balance: {
    keys: [
      0,
      60,
      cue("balance", "Open Why") - 12,
      cue("balance", "Open Why") + 28,
      303,
    ],
    scale: [1, 1.35, 1.35, 1.45, 1.45],
    cx: [0.5, 0.48, 0.48, 0.49, 0.49],
    cy: [0.42, 0.3, 0.3, 0.4, 0.4],
    titles: [{ at: 0, text: "Every answer shows its [source.]" }],
  },
  trace: {
    keys: [0, 60, 115, 180, 405, 451, 490, 552],
    scale: [1, 1.35, 1.35, 1.23, 1.23, 1, 1, 1],
    cx: [0.5, 0.49, 0.49, 0.49, 0.49, 0.5, 0.5, 0.5],
    cy: [0.4, 0.3, 0.3, 0.54, 0.54, 0.45, 0.25, 0.25],
    titles: [{ at: 0, text: "Nothing happens without a [yes.]" }],
  },
  portuguese: {
    keys: [0, 60, 276],
    scale: [1, 1.5, 1.5],
    cx: [0.5, 0.49, 0.49],
    cy: [0.4, 0.31, 0.31],
    titles: [{ at: 0, text: "Same checks, [em português.]" }],
  },
  handoff: {
    keys: [0, 60, 125, 165, 220, 330, 390, 456],
    scale: [1, 1.24, 1.24, 1, 1.55, 1.55, 1.55, 1.55],
    cx: [0.5, 0.43, 0.43, 0.5, 0.81, 0.81, 0.81, 0.81],
    cy: [0.44, 0.59, 0.59, 0.4, 0.4, 0.4, 0.3, 0.3],
    titles: [{ at: 0, text: "Sensitive cases reach a [person.]" }],
  },
  safety: {
    keys: [0, 60, 165, 195, 245, 325, 385, 447],
    scale: [1, 1.3, 1.3, 1, 1.3, 1.3, 1.3, 1.3],
    cx: [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5],
    cy: [0.4, 0.3, 0.3, 0.43, 0.39, 0.39, 0.68, 0.68],
    titles: [
      { at: 0, text: "Someone else's data stays [hidden.]" },
      { at: 183, text: "Simulated outage. Verified balances [still work.]" },
    ],
  },
});
let cached: Record<string, Plan> | undefined;
const planFor = (id: string) => {
  cached ??= plans();
  return cached[id];
};

// Keeps the crop inside the recording so no empty edge shows once the frame is filled.
const inside = (center: number, scale: number, half: number, size: number) => {
  const min = half / (size * scale);
  return min >= 0.5 ? 0.5 : Math.min(1 - min, Math.max(min, center));
};

// The camera crops the actual screen recording. It never reconstructs an app response.
const Camera: React.FC<
  React.PropsWithChildren<{
    clip: string;
    scale: number;
    cx: number;
    cy: number;
  }>
> = ({ clip, scale, cx: rawX, cy: rawY, children }) => {
  const cx = inside(rawX, scale, 960, 1920);
  const cy = inside(rawY, scale, 540, 1200);
  return (
    <div
      style={{
        position: "absolute",
        left: 960 - cx * 1920 * scale,
        top: 540 - cy * 1200 * scale,
        width: 1920 * scale,
        height: 1200 * scale,
      }}
    >
      <OffthreadVideo
        src={staticFile(`clips/${clip}`)}
        muted
        style={{ width: "100%", height: "100%" }}
      />
      {children}
    </div>
  );
};

const plain = (t: string) => t.replace(/[[\]]/g, "");

const LabelPill: React.FC<{ titles: Plan["titles"]; tag: string }> = ({
  titles,
  tag,
}) => {
  const f = useCurrentFrame();
  const current =
    [...titles].reverse().find((t) => f >= t.at) ?? titles[0];
  const o = ramp(f, current.at, 20);
  return (
    <div
      style={{
        position: "absolute",
        left: 48,
        top: 34,
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "10px 22px 10px 10px",
        borderRadius: 999,
        background: B.glassLabel,
        boxShadow: "0 8px 24px #0B2A931F",
        backdropFilter: "blur(10px)",
        opacity: ramp(f, 6, 20),
        transform: `translateY(${(1 - ramp(f, 6, 24)) * 8}px)`,
      }}
    >
      <span
        style={{
          fontFamily: F.mono,
          fontSize: 17,
          padding: "6px 11px",
          borderRadius: 999,
          background: B.blue,
          color: "#FFFFFF",
          letterSpacing: 1,
        }}
      >
        {tag}
      </span>
      <span
        style={{
          fontSize: 25,
          fontWeight: 650,
          letterSpacing: -0.5,
          color: B.sky900,
          opacity: o,
        }}
      >
        {plain(current.text)}
      </span>
    </div>
  );
};

export const Demo: React.FC<{ scene: Scene }> = ({ scene }) => {
  const f = useCurrentFrame();
  const plan = planFor(scene.id);
  const at = (values: number[]) =>
    interpolate(f, plan.keys, values, { ...clamp, easing: easeInOut });
  const tag = scene.tag ?? "";
  return (
    <AbsoluteFill style={{ background: B.gray100 }}>
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(60% 60% at 85% 100%, #DCE8FF 0%, #DCE8FF00 100%)",
        }}
      />
      <AbsoluteFill
        style={{
          overflow: "hidden",
          background: "#FFFFFF",
        }}
      >
        <Camera
          clip={scene.clip ?? ""}
          scale={at(plan.scale)}
          cx={at(plan.cx)}
          cy={at(plan.cy)}
        />
      </AbsoluteFill>
      <LabelPill titles={plan.titles} tag={tag} />
      <div
        style={{
          position: "absolute",
          right: 48,
          top: 40,
          display: "flex",
          alignItems: "center",
          gap: 10,
          padding: "10px 18px",
          borderRadius: 999,
          background: B.glassLabel,
          fontFamily: F.mono,
          fontSize: 16,
          color: B.inkApp,
          opacity: ramp(f, 6, 20),
        }}
      >
        <span
          style={{
            width: 9,
            height: 9,
            borderRadius: 9,
            background: B.blue,
            opacity: 1,
          }}
        />
        Real deployed app · synthetic data
      </div>
    </AbsoluteFill>
  );
};
