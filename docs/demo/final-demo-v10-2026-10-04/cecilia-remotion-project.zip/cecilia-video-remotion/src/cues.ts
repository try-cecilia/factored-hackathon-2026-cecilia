import timelineData from "./data/timeline.json";
import master from "../public/audio/continuous.json";

export type Scene = {
  id: string;
  type: string;
  title: string;
  chapter: string;
  seconds: number;
  from: number;
  duration: number;
  visualDuration: number;
  characterStart: number;
  audio: string;
  audioOffset: number;
  spokenSeconds: number;
  text: string;
  clip?: string;
  tag?: string;
};
export const scenes: Scene[] = timelineData;

// Convert the uninterrupted track's word alignment to each visual scene's frame.
export const cue = (sceneId: string, phrase: string): number => {
  const scene = scenes.find((s) => s.id === sceneId);
  const at = scene?.text.indexOf(phrase) ?? -1;
  if (!scene || at < 0) throw new Error(`No cue "${phrase}" in ${sceneId}`);
  return Math.round(master.alignment.character_start_times_seconds[scene.characterStart + at] * 30) - scene.from;
};
