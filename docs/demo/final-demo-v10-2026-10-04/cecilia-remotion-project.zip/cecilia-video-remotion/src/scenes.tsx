import React from "react";
import {
  AbsoluteFill,
  Img,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";
import {
  B,
  Eyebrow,
  F,
  Kinetic,
  Odometer,
  Rise,
  Sky,
  Wordmark,
  clamp,
  ease,
  easeInOut,
  pop,
  ramp,
  tileRadius,
} from "./brand";
import { cue } from "./cues";

// Questions typed by the test customers in the recordings. Only questions: no bank reply is recreated here.
const Bubble: React.FC<{
  text: string;
  lang: string;
  at: number;
  x: number;
  y: number;
  drift: number;
}> = ({ text, lang, at, x, y, drift }) => {
  const f = useCurrentFrame();
  const p = pop(f, at, 16);
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y + Math.sin((f + drift) / 26) * 6,
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "16px 22px 16px 16px",
        background: "#FFFFFF",
        borderRadius: tileRadius(56),
        boxShadow: "0 24px 60px #0B2A9340",
        opacity: Math.min(1, p * 1.4),
        transform: `scale(${0.6 + 0.4 * p}) translateY(${(1 - p) * 30}px)`,
        transformOrigin: "100% 100%",
        whiteSpace: "nowrap",
      }}
    >
      <span
        style={{
          fontFamily: F.mono,
          fontSize: 15,
          padding: "4px 8px",
          borderRadius: 6,
          background: B.sky100,
          color: B.sky900,
        }}
      >
        {lang}
      </span>
      <span style={{ fontSize: 25, color: B.inkApp, letterSpacing: -0.3 }}>
        {text}
      </span>
    </div>
  );
};

export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const rise = pop(f, 4, 22);
  const push = interpolate(f, [0, 300], [1, 1.05]);
  return (
    <AbsoluteFill style={{ fontFamily: F.sans }}>
      <Sky />
      <AbsoluteFill style={{ transform: `scale(${push})` }}>
        <Img
          src={staticFile("images/cecilia-hero.png")}
          style={{
            position: "absolute",
            width: 980,
            right: -40,
            bottom: -170 + Math.sin(f / 30) * 6,
            transform: `translateY(${(1 - rise) * 420}px)`,
            filter: "drop-shadow(0 40px 60px #0B2A9366)",
          }}
        />
        <Bubble
          text="¿Cuál es mi saldo?"
          lang="ES"
          at={cue("intro", "Spanish-")}
          x={1330}
          y={190}
          drift={0}
        />
        <Bubble
          text="Tenho pagamentos atrasados no meu cartão?"
          lang="PT"
          at={cue("intro", "Portuguese-")}
          x={1180}
          y={890}
          drift={20}
        />
        <Bubble
          text="¿Pueden rastrear mi transferencia?"
          lang="ES"
          at={cue("intro", "pending transfer")}
          x={1010}
          y={700}
          drift={40}
        />
      </AbsoluteFill>
      <div style={{ position: "absolute", left: 120, top: 92 }}>
        <Wordmark size={46} at={2} color="#FFFFFF" />
      </div>
      <div style={{ position: "absolute", left: 120, top: 290, width: 840 }}>
        <Kinetic
          text="Account and payment answers, / from the bank's [own data.]"
          start={10}
          stagger={4}
          marker="#FFFFFF"
          accent={B.blue}
          style={{
            fontSize: 92,
            fontWeight: 700,
            letterSpacing: -4,
            lineHeight: 1.04,
            color: "#FFFFFF",
          }}
        />
        <Rise at={cue("intro", "Spanish-")} style={{ marginTop: 52 }}>
          <div
            style={{
              fontSize: 34,
              fontWeight: 500,
              color: "#FFFFFFE6",
              letterSpacing: -0.6,
              lineHeight: 1.3,
            }}
          >
            For bank customers who write in
            <br />
            Spanish and Portuguese.
          </div>
          <div style={{ display: "flex", gap: 12, marginTop: 28 }}>
            {["ES", "PT", "MX · CO · AR"].map((t, i) => (
              <span
                key={t}
                style={{
                  fontFamily: F.mono,
                  fontSize: 19,
                  padding: "9px 16px",
                  borderRadius: 999,
                  background: B.glassLabel,
                  color: B.sky900,
                  opacity: ramp(f, cue("intro", "Spanish-") + 6 + i * 5, 10),
                }}
              >
                {t}
              </span>
            ))}
          </div>
          {/* The rest of the spoken promise, one pill per beat. */}
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              gap: 12,
              marginTop: 40,
            }}
          >
            {[
              {
                t: "Bank answers show source and date",
                at: cue("intro", "see where"),
              },
              {
                t: "Sensitive cases go to a person",
                at: cue("intro", "Anything sensitive"),
              },
            ].map(({ t, at }) => (
              <span
                key={t}
                style={{
                  fontSize: 26,
                  fontWeight: 600,
                  letterSpacing: -0.4,
                  padding: "12px 22px",
                  borderRadius: 999,
                  background: "#FFFFFF",
                  color: B.ink,
                  boxShadow: "0 14px 34px #0B2A9326",
                  opacity: ramp(f, at, 8),
                  transform: `translateY(${(1 - pop(f, at, 12)) * 16}px)`,
                }}
              >
                {t}
              </span>
            ))}
          </div>
        </Rise>
      </div>
    </AbsoluteFill>
  );
};

const Corner: React.FC<{ label: string; dark?: boolean }> = ({
  label,
  dark,
}) => (
  <div
    style={{
      position: "absolute",
      left: 64,
      right: 64,
      top: 44,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
    }}
  >
    <Wordmark size={28} color={dark ? "#FFFFFF" : B.ink} />
    <Eyebrow color={dark ? B.onInkMuted : B.muted} style={{ fontSize: 16 }}>
      {label}
    </Eyebrow>
  </div>
);

// 200 chat tiles stand for the contact history; 35 % turn Cecilia blue in a diagonal sweep.
export const Problem: React.FC = () => {
  const f = useCurrentFrame();
  const share = cue("problem", "thirty-five");
  const queue = cue("problem", "queue");
  const sat = cue("problem", "satisfaction");
  const cols = 20;
  const lit = new Set(
    Array.from({ length: 200 }, (_, i) => i)
      .sort((a, b) => ((a * 73) % 200) - ((b * 73) % 200))
      .slice(0, 70),
  );
  return (
    <AbsoluteFill style={{ background: "#FFFFFF", fontFamily: F.sans }}>
      <Corner label="Synthetic bank history" />
      <div style={{ position: "absolute", left: 120, top: 210, width: 820 }}>
        <Eyebrow>Account and payment questions</Eyebrow>
        <Kinetic
          text="More than [a third] of all contacts."
          start={8}
          stagger={4}
          style={{
            fontSize: 84,
            fontWeight: 700,
            letterSpacing: -3.6,
            lineHeight: 1.04,
            marginTop: 26,
          }}
        />
        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            gap: 24,
            marginTop: 48,
          }}
        >
          <Odometer
            value="35%"
            progress={interpolate(f, [share - 6, share + 30], [0, 1], {
              ...clamp,
              easing: ease,
            })}
            size={190}
            color={B.blue}
          />
          <Rise
            at={share + 18}
            style={{
              fontSize: 27,
              color: B.muted,
              paddingBottom: 26,
              lineHeight: 1.35,
            }}
          >
            of 686,296
            <br />
            contacts
          </Rise>
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 1030,
          top: 230,
          display: "grid",
          gridTemplateColumns: `repeat(${cols}, 30px)`,
          gap: 10,
        }}
      >
        {Array.from({ length: 200 }, (_, i) => {
          const r = Math.floor(i / cols);
          const c = i % cols;
          const appear = ramp(f, 4 + (r + c) * 0.9, 10);
          const on = lit.has(i) ? ramp(f, share - 4 + (r + c) * 1.1, 8) : 0;
          return (
            <div
              key={i}
              style={{
                width: 30,
                height: 30,
                borderRadius: tileRadius(30),
                background: on > 0.5 ? B.blue : B.gray200,
                opacity: appear,
                transform: `scale(${0.4 + 0.6 * appear + on * (1 - on) * 0.8})`,
              }}
            />
          );
        })}
      </div>
      <div
        style={{
          position: "absolute",
          left: 1030,
          top: 660,
          display: "flex",
          gap: 24,
          width: 790,
        }}
      >
        <Rise
          at={queue}
          style={{
            flex: 1,
            padding: "26px 28px",
            borderRadius: 24,
            background: B.gray100,
          }}
        >
          <div style={{ fontSize: 22, color: B.muted }}>Average queue</div>
          <div
            style={{
              fontFamily: F.mono,
              fontSize: 60,
              letterSpacing: -2,
              marginTop: 10,
            }}
          >
            120 s
          </div>
          <div
            style={{
              height: 8,
              borderRadius: 8,
              background: B.gray200,
              marginTop: 18,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                height: "100%",
                width: `${interpolate(f, [queue + 6, queue + 60], [0, 100], clamp)}%`,
                background: B.ink,
              }}
            />
          </div>
        </Rise>
        <Rise
          at={sat}
          style={{
            flex: 1,
            padding: "26px 28px",
            borderRadius: 24,
            background: B.gray100,
          }}
        >
          <div style={{ fontSize: 22, color: B.muted }}>Satisfaction</div>
          <div
            style={{
              fontFamily: F.mono,
              fontSize: 60,
              letterSpacing: -2,
              marginTop: 10,
            }}
          >
            2.91<span style={{ color: B.muted, fontSize: 36 }}> / 5</span>
          </div>
          <div style={{ display: "flex", gap: 6, marginTop: 18 }}>
            {[0, 1, 2, 3, 4].map((i) => (
              <div
                key={i}
                style={{
                  flex: 1,
                  height: 8,
                  borderRadius: 8,
                  background: B.gray200,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    background: B.ink,
                    width: `${Math.max(0, Math.min(1, 2.91 * ramp(f, sat + 6, 40) - i)) * 100}%`,
                  }}
                />
              </div>
            ))}
          </div>
        </Rise>
      </div>
      <Rise
        at={sat + 20}
        style={{
          position: "absolute",
          left: 120,
          bottom: 120,
          fontFamily: F.mono,
          fontSize: 18,
          color: B.muted,
        }}
      >
        Synthetic historical data from the organizer · no forecast of savings or
        satisfaction
      </Rise>
    </AbsoluteFill>
  );
};

// Two lanes: the model works above the line, the bank's data and code below. Customer records never cross upward.
export const HowItWorks: React.FC = () => {
  const f = useCurrentFrame();
  const choose = cue("architecture", "chooses");
  const checks = cue("architecture", "Code checks");
  const reads = cue("architecture", "reads the bank record");
  const writes = cue("architecture", "writes the reply");
  const never = cue("architecture", "Customer records");
  const tools = [
    "list_transactions",
    "get_payment_status",
    "get_exchange_rate",
    "get_account_summary",
  ];
  const spin = interpolate(f, [choose, choose + 34], [0, tools.length - 1], {
    ...clamp,
    easing: ease,
  });
  const drop = interpolate(f, [checks - 10, checks + 6], [0, 1], {
    ...clamp,
    easing: easeInOut,
  });
  const gate = ramp(f, never, 14);
  const steps = [
    { at: checks + 2, t: "Ownership checked" },
    { at: reads, t: "Bank record read" },
    { at: writes, t: "Reply written from verified data" },
  ];
  return (
    <AbsoluteFill style={{ background: "#FFFFFF", fontFamily: F.sans }}>
      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          top: 0,
          height: 560,
          background: B.sky,
          opacity: 0.16,
        }}
      />
      <Corner label="How every answer is made" />
      <div style={{ position: "absolute", left: 120, top: 150 }}>
        <Kinetic
          text="The model [chooses.] The code [checks.]"
          start={6}
          stagger={4}
          style={{ fontSize: 88, fontWeight: 700, letterSpacing: -3.8 }}
        />
      </div>
      {/* Model lane */}
      <Eyebrow style={{ position: "absolute", left: 120, top: 330 }}>
        Model
      </Eyebrow>
      <Rise at={10} style={{ position: "absolute", left: 120, top: 380 }}>
        <div
          style={{
            padding: "18px 26px",
            background: "#FFFFFF",
            borderRadius: tileRadius(64),
            boxShadow: "0 16px 40px #0B2A9326",
            fontSize: 30,
            color: B.inkApp,
          }}
        >
          <span
            style={{
              fontFamily: F.mono,
              fontSize: 16,
              color: B.sky900,
              marginRight: 14,
            }}
          >
            ES
          </span>
          ¿Cuál es mi saldo?
        </div>
      </Rise>
      <div
        style={{
          position: "absolute",
          left: 600,
          top: 410,
          width: interpolate(f, [choose - 10, choose + 4], [0, 230], clamp),
          height: 3,
          background: B.blue,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: 860,
          top: 372,
          height: 78,
          width: 470,
          overflow: "hidden",
          borderRadius: 18,
          background: spin >= tools.length - 1.02 ? B.blue : B.ink,
          color: "#FFFFFF",
          opacity: ramp(f, choose - 6, 8),
          boxShadow: "0 20px 50px #014FFB40",
        }}
      >
        <div style={{ transform: `translateY(${-spin * 78}px)` }}>
          {tools.map((t) => (
            <div
              key={t}
              style={{
                height: 78,
                display: "flex",
                alignItems: "center",
                padding: "0 26px",
                fontFamily: F.mono,
                fontSize: 28,
              }}
            >
              {t}()
            </div>
          ))}
        </div>
      </div>
      <Rise
        at={choose + 10}
        style={{
          position: "absolute",
          left: 1360,
          top: 390,
          fontSize: 24,
          color: B.muted,
          width: 420,
        }}
      >
        It picks a lookup. It never sees the records.
      </Rise>
      {/* The line */}
      <div
        style={{
          position: "absolute",
          left: 120,
          right: 120,
          top: 560,
          height: 4,
          borderRadius: 4,
          background: B.blue,
          opacity: 0.25 + 0.75 * gate,
          boxShadow: `0 0 ${30 * gate}px ${B.blue}`,
        }}
      />
      <div
        style={{
          position: "absolute",
          right: 120,
          top: 520,
          padding: "8px 16px",
          borderRadius: 999,
          background: B.blue,
          color: "#FFFFFF",
          fontSize: 21,
          fontWeight: 600,
          opacity: gate,
          transform: `translateY(${(1 - gate) * 10}px)`,
        }}
      >
        Customer records never enter the model request
      </div>
      {/* Bank lane */}
      <div
        style={{
          position: "absolute",
          left: 120,
          right: 120,
          top: 600,
          bottom: 110,
          borderRadius: 32,
          background: B.ink,
        }}
      />
      <Eyebrow
        color={B.sky300}
        style={{ position: "absolute", left: 170, top: 640 }}
      >
        Bank data + code
      </Eyebrow>
      {[
        "Cuenta Ahorro ···8344",
        "Cuenta Corriente ···6481",
        "Tarjeta Crédito ···9194",
      ].map((t, i) => {
        const bump =
          never > 0
            ? Math.max(0, Math.sin(((f - never - i * 5) / 16) * Math.PI)) *
              (f > never + i * 5 && f < never + i * 5 + 16 ? 1 : 0)
            : 0;
        return (
          <div
            key={t}
            style={{
              position: "absolute",
              left: 170 + i * 220,
              top: 720 - bump * 40,
              width: 200,
              padding: "14px 16px",
              borderRadius: 14,
              background: "#FFFFFF14",
              border: "1px solid #FFFFFF22",
              fontFamily: F.mono,
              fontSize: 15,
              color: B.onInkMuted,
              opacity: ramp(f, 14 + i * 4, 12),
            }}
          >
            {t}
          </div>
        );
      })}
      <div
        style={{
          position: "absolute",
          left: 1093,
          top: 450,
          width: 4,
          height: drop * 236,
          borderRadius: 4,
          background: B.blue,
          zIndex: 2,
        }}
      />
      <div style={{ position: "absolute", left: 1000, top: 690, width: 760 }}>
        {steps.map((s) => {
          const p = ramp(f, s.at, 12);
          return (
            <div
              key={s.t}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 18,
                height: 74,
                opacity: p,
                transform: `translateX(${(1 - p) * 30}px)`,
                color: "#FFFFFF",
                fontSize: 32,
                fontWeight: 600,
                letterSpacing: -0.6,
              }}
            >
              <span
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 34,
                  background: B.blue,
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 19,
                }}
              >
                ✓
              </span>
              {s.t}
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

// The landing's black results band. 548 tiles, one per team-written case.
export const Evidence: React.FC = () => {
  const f = useCurrentFrame();
  const scope = cue("evidence", "two hundred thirty-eight");
  const rate = cue("evidence", "ninety-seven");
  const keywords = cue("evidence", "seventy point two");
  const runs = cue("evidence", "Three runs");
  const missed = cue("evidence", "though the first run");
  const cols = 26;
  const inScope = (i: number) => (i * 89) % 548 < 238;
  const missedTile = 211;
  const bars = interpolate(f, [runs - 6, runs + 4], [1, 0], clamp);
  return (
    <AbsoluteFill
      style={{ background: B.ink, color: "#FFFFFF", fontFamily: F.sans }}
    >
      <Corner label="Measured · team-written ES + PT tests" dark />
      <div style={{ position: "absolute", left: 120, top: 150 }}>
        <Kinetic
          text="Tested on [548] cases we wrote."
          start={6}
          stagger={4}
          accent={B.sky300}
          style={{ fontSize: 80, fontWeight: 700, letterSpacing: -3.4 }}
        />
      </div>
      <div
        style={{
          position: "absolute",
          left: 120,
          top: 330,
          display: "grid",
          gridTemplateColumns: `repeat(${cols}, 20px)`,
          gap: 6,
        }}
      >
        {Array.from({ length: 548 }, (_, i) => {
          const r = Math.floor(i / cols);
          const c = i % cols;
          const appear = ramp(f, 8 + (r + c) * 0.7, 10);
          const scoped = inScope(i);
          const focus = ramp(f, scope + (r + c) * 0.5, 10);
          const flag = i === missedTile ? ramp(f, missed, 8) : 0;
          return (
            <div
              key={i}
              style={{
                width: 20,
                height: 20,
                borderRadius: tileRadius(20),
                background:
                  flag > 0
                    ? B.caution
                    : scoped && focus > 0.5
                      ? B.sky500
                      : "#FFFFFF",
                opacity:
                  appear * (scoped ? 0.5 + 0.5 * focus : 0.5 - 0.36 * focus),
                transform: `scale(${1 + flag * 0.5})`,
                boxShadow: flag ? `0 0 ${24 * flag}px ${B.caution}` : undefined,
              }}
            />
          );
        })}
      </div>
      <Rise
        at={scope}
        style={{
          position: "absolute",
          left: 120,
          top: 915,
          fontFamily: F.mono,
          fontSize: 17,
          color: B.onInkMuted,
        }}
      >
        548 cases · <span style={{ color: B.sky300 }}>■</span> 238 in scope
      </Rise>
      <div
        style={{
          position: "absolute",
          left: 1000,
          top: 340,
          width: 800,
          opacity: bars,
        }}
      >
        <Rise at={rate - 10}>
          <Eyebrow color={B.sky300}>
            Safe resolution · in scope · first run
          </Eyebrow>
        </Rise>
        {[
          {
            l: "Cecilia · Sonnet 5",
            v: "97.1%",
            n: 97.1,
            at: rate,
            c: B.sky500,
          },
          {
            l: "Keyword baseline",
            v: "70.2%",
            n: 70.2,
            at: keywords,
            c: "#8A8A92",
          },
        ].map((b) => {
          const p = interpolate(f, [b.at - 4, b.at + 30], [0, 1], {
            ...clamp,
            easing: ease,
          });
          return (
            <div
              key={b.l}
              style={{ marginTop: 44, opacity: ramp(f, b.at - 6, 8) }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "flex-end",
                }}
              >
                <span style={{ fontSize: 28, color: B.onInkMuted }}>{b.l}</span>
                <Odometer
                  value={b.v}
                  progress={p}
                  size={96}
                  color={b.c === B.sky500 ? "#FFFFFF" : B.onInkMuted}
                />
              </div>
              <div
                style={{
                  height: 14,
                  borderRadius: 14,
                  background: "#FFFFFF1A",
                  marginTop: 16,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${b.n * p}%`,
                    background: b.c,
                    borderRadius: 14,
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
      <div
        style={{
          position: "absolute",
          left: 1000,
          top: 340,
          width: 800,
          opacity: 1 - bars,
        }}
      >
        <Eyebrow color={B.sky300}>Unsafe outcomes · all 548 cases</Eyebrow>
        <div style={{ display: "flex", gap: 18, marginTop: 36 }}>
          {[1, 2, 3].map((run) => {
            const p = pop(f, runs + run * 6, 16);
            return (
              <div
                key={run}
                style={{
                  flex: 1,
                  padding: "24px 26px",
                  borderRadius: 24,
                  background: "#FFFFFF10",
                  border: "1px solid #FFFFFF1F",
                  transform: `scale(${0.85 + 0.15 * p})`,
                  opacity: Math.min(1, p * 1.5),
                }}
              >
                <div
                  style={{
                    fontFamily: F.mono,
                    fontSize: 17,
                    color: B.onInkMuted,
                  }}
                >
                  Run {run}
                </div>
                <div
                  style={{
                    fontSize: 120,
                    fontWeight: 600,
                    letterSpacing: -4,
                    lineHeight: 1.05,
                    marginTop: 8,
                  }}
                >
                  0
                </div>
                <div style={{ fontSize: 20, color: B.onInkMuted }}>unsafe</div>
              </div>
            );
          })}
        </div>
        <Rise
          at={missed}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 18,
            marginTop: 30,
            padding: "20px 24px",
            borderRadius: 20,
            border: `1px solid ${B.caution}66`,
            fontSize: 26,
            lineHeight: 1.3,
          }}
        >
          <span
            style={{
              width: 22,
              height: 22,
              flexShrink: 0,
              borderRadius: tileRadius(22),
              background: B.caution,
            }}
          />
          <span>
            Run 1 missed <b>one required escalation.</b>
          </span>
        </Rise>
      </div>
      <Rise
        at={missed + 30}
        style={{
          position: "absolute",
          left: 1000,
          top: 930,
          width: 800,
          fontFamily: F.mono,
          fontSize: 17,
          lineHeight: 1.5,
          color: B.onInkMuted,
        }}
      >
        Team-written tests. Zero observed unsafe outcomes is not proof of zero
        risk.
      </Rise>
    </AbsoluteFill>
  );
};

// Continue the evaluation with its operational meaning, using measured values only.
export const Impact: React.FC = () => {
  const f = useCurrentFrame();
  const gain = cue("impact", "twenty-six");
  const handoff = cue("impact", "All one hundred");
  const speed = cue("impact", "Speed mattered");
  const median = cue("impact", "half of responses");
  const p95 = cue("impact", "ninety-five percent");
  return (
    <AbsoluteFill style={{ background: "#FFFFFF", fontFamily: F.sans, color: B.ink }}>
      <Corner label="What the results mean · live-model evaluation" />
      <div style={{ position: "absolute", left: 120, top: 150, width: 1680 }}>
        <Kinetic text="More useful answers. [Better handoffs.]" start={6} stagger={2}
          style={{ fontSize: 78, fontWeight: 700, letterSpacing: -3.2 }} />
        <Rise at={14} style={{ fontFamily: F.mono, color: B.muted, fontSize: 20, marginTop: 24 }}>
          Sonnet 5 · run 1 · 548 team-written ES + PT cases
        </Rise>
      </div>
      <div style={{ position: "absolute", left: 120, top: 390, width: 730 }}>
        <Rise at={gain - 6}>
          <Eyebrow color={B.blue}>Safe automated resolution</Eyebrow>
          <div style={{ display: "flex", alignItems: "baseline", gap: 16, marginTop: 35 }}>
            <span style={{ fontSize: 92, color: B.blue }}>+</span>
            <Odometer value="26.9" progress={ramp(f, gain, 32)} size={174} color={B.blue} />
            <span style={{ fontFamily: F.mono, fontSize: 35, color: B.muted }}>pp</span>
          </div>
          <div style={{ fontSize: 36, fontWeight: 600, marginTop: 25, letterSpacing: -.8 }}>
            above the keyword baseline
          </div>
          <div style={{ fontSize: 29, color: B.muted, marginTop: 35 }}>
            70.2% → 97.1% · 238 in-scope cases
          </div>
          <div style={{ height: 10, background: B.gray200, borderRadius: 8, marginTop: 24, width: 630, overflow: "hidden" }}>
            <div style={{ width: `${70.2 + 26.9 * ramp(f, gain, 40)}%`, height: "100%", background: B.blue, borderRadius: 8 }} />
          </div>
        </Rise>
      </div>
      <div style={{ position: "absolute", left: 940, top: 380, width: 860, borderLeft: `1px solid ${B.line}`, paddingLeft: 65 }}>
        <Rise at={handoff}>
          <Eyebrow color={B.blue}>Context reaches the operator</Eyebrow>
          <div style={{ display: "flex", alignItems: "baseline", gap: 20, marginTop: 20 }}>
            <Odometer value="171" progress={ramp(f, handoff, 30)} size={105} />
            <span style={{ fontFamily: F.mono, color: B.muted, fontSize: 40 }}>/ 171 handoffs</span>
          </div>
          <div style={{ fontSize: 27, color: B.muted, marginTop: 17 }}>All required handoff fields present</div>
        </Rise>
        <Rise at={speed} style={{ marginTop: 42, borderTop: `1px solid ${B.line}`, paddingTop: 28 }}>
          <Eyebrow color={B.blue}>End-to-end test case time</Eyebrow>
          <div style={{ display: "flex", gap: 75, marginTop: 28 }}>
            {[{value: "1.43", label: "Median", at: median}, {value: "2.99", label: "95th percentile", at: p95}].map((item) => (
              <Rise key={item.label} at={item.at}>
                <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
                  <Odometer value={item.value} progress={ramp(f, item.at, 24)} size={78} />
                  <span style={{ fontFamily: F.mono, fontSize: 28 }}>s</span>
                </div>
                <div style={{ fontSize: 23, color: B.muted, marginTop: 16 }}>{item.label}</div>
              </Rise>
            ))}
          </div>
        </Rise>
      </div>
      <Rise at={12} style={{ position: "absolute", left: 120, top: 945, fontFamily: F.mono, fontSize: 16, color: B.muted }}>
        Source: October 4 system evaluation · synthetic workload · latency measured in evaluation
      </Rise>
    </AbsoluteFill>
  );
};

// Finish the measured results with the deployed demo and a direct invitation.
export const Closing: React.FC = () => {
  const f = useCurrentFrame();
  const open = cue("closing", "Try the");
  const iris = interpolate(f, [open - 8, open + 22], [0, 1], {
    ...clamp,
    easing: easeInOut,
  });
  const card = ramp(f, open + 4, 30);
  return (
    <AbsoluteFill style={{ background: "#FFFFFF", fontFamily: F.sans }}>
      <Corner label="Try Cecilia" />
      <div style={{ position: "absolute", left: 120, top: 240, width: 1680, display: "flex", alignItems: "center", gap: 90 }}>
        <Odometer value="7 / 7" progress={ramp(f, 4, 26)} size={190} color={B.blue} />
        <div>
          <Kinetic text="Selected scenarios. / [Passed on the deployed app.]" start={8} stagger={2}
            style={{ fontSize: 65, fontWeight: 700, letterSpacing: -2.5, lineHeight: 1.12 }} />
          <Rise at={18} style={{ fontFamily: F.mono, fontSize: 24, color: B.muted, marginTop: 35 }}>
            Spanish + Portuguese · customer app + bank console
          </Rise>
        </div>
      </div>
      {/* The sky opens as a circle from where Cecilia's avatar will sit. */}
      <AbsoluteFill
        style={{ clipPath: `circle(${iris * 2300}px at 600px 540px)` }}
      >
        <Sky />
        <div
          style={{
            position: "absolute",
            left: 340,
            top: 280,
            width: 520,
            height: 520,
            borderRadius: 520,
            background: "#FFFFFF26",
            border: "2px solid #FFFFFF55",
            overflow: "hidden",
            transform: `scale(${0.95 + 0.05 * card})`,
          }}
        >
          <Img
            src={staticFile("images/cecilia-hero.png")}
            style={{
              position: "absolute",
              width: 600,
              left: -40,
              top: 30 + (1 - card) * 24,
            }}
          />
        </div>
        <div style={{ position: "absolute", left: 960, top: 268, width: 840 }}>
          <Wordmark size={60} at={open + 4} color="#FFFFFF" />
          <Kinetic
            text="Verified answers. / A person when it [matters.]"
            start={open + 8}
            stagger={1.6}
            revealFrames={20}
            marker="#FFFFFF"
            accent={B.blue}
            style={{
              fontSize: 70,
              fontWeight: 700,
              letterSpacing: -2.8,
              lineHeight: 1.08,
              color: "#FFFFFF",
              marginTop: 44,
            }}
          />
          <Rise
            at={open + 14}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 28,
              marginTop: 52,
            }}
          >
            <div
              style={{
                padding: "22px 34px",
                borderRadius: 999,
                background: "#FFFFFF",
                color: B.ink,
                fontSize: 30,
                fontWeight: 650,
                letterSpacing: -0.5,
              }}
            >
              Try the demo&nbsp;&nbsp;→
            </div>
            <div style={{ fontFamily: F.mono, fontSize: 28, color: "#FFFFFF" }}>
              cecil-ai.onrender.com
            </div>
          </Rise>
          <Rise
            at={open + 18}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 22,
              marginTop: 44,
            }}
          >
            <div
              style={{ padding: 10, borderRadius: 16, background: "#FFFFFF" }}
            >
              <Img
                src={staticFile("images/demo-qr.png")}
                style={{ width: 120, height: 120, display: "block" }}
              />
            </div>
            <div
              style={{
                fontFamily: F.mono,
                fontSize: 18,
                lineHeight: 1.6,
                color: "#FFFFFFD9",
              }}
            >
              Customer app + bank console
              <br />
              Live demo · synthetic data
              <br />
              Public repository: pending
            </div>
          </Rise>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
