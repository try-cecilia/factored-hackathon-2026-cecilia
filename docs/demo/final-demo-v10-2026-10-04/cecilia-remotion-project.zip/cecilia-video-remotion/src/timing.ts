import timeline from "./data/timeline.json";

export const TRANSITION_FRAMES = 18;
export const TOTAL_FRAMES = timeline.reduce(
  (total, scene) => total + scene.duration,
  0,
);
