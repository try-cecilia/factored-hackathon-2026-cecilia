import React from "react";
import {
  AbsoluteFill,
  Html5Audio,
  interpolate,
  Easing,
  staticFile,
  useCurrentFrame,
} from "remotion";
import {
  TransitionSeries,
  linearTiming,
  type TransitionPresentation,
  type TransitionPresentationComponentProps,
} from "@remotion/transitions";
import captions from "./data/captions.json";
import { TOTAL_FRAMES, TRANSITION_FRAMES } from "./timing";
import { B, F, clamp, useBrandFonts } from "./brand";
import { scenes, type Scene } from "./cues";
import { Demo } from "./demo";
import { Closing, Evidence, Hook, HowItWorks, Impact, Problem } from "./scenes";

// A restrained dissolve keeps the visual change underneath the continuous voice.
const Dissolve: React.FC<
  TransitionPresentationComponentProps<Record<string, never>>
> = ({ children, presentationDirection, presentationProgress: p }) => (
  <AbsoluteFill style={presentationDirection === "entering" ? { opacity: p } : {}}>
    {children}
  </AbsoluteFill>
);
const dissolve = (): TransitionPresentation<Record<string, never>> => ({
  component: Dissolve,
  props: {},
});

const SceneView: React.FC<{ scene: Scene }> = ({ scene }) => (
  <AbsoluteFill
    style={{ fontFamily: F.sans, color: B.ink, overflow: "hidden" }}
  >
    {scene.type === "intro" ? (
      <Hook />
    ) : scene.type === "problem" ? (
      <Problem />
    ) : scene.type === "promise" ? (
      <HowItWorks />
    ) : scene.type === "evidence" ? (
      <Evidence />
    ) : scene.type === "impact" ? (
      <Impact />
    ) : scene.type === "closing" ? (
      <Closing />
    ) : (
      <Demo scene={scene} />
    )}
  </AbsoluteFill>
);

const Captions: React.FC = () => {
  const f = useCurrentFrame();
  const cue = captions.find((c) => c.start <= f / 30 && c.end > f / 30);
  return cue ? (
    <div
      style={{
        position: "absolute",
        left: 100,
        right: 100,
        bottom: 30,
        textAlign: "center",
        fontFamily: F.sans,
        fontSize: 28,
        lineHeight: 1.3,
        color: "#FFFFFF",
      }}
    >
      <span
        style={{
          background: "#000000D9",
          padding: "9px 18px",
          borderRadius: 10,
          boxDecorationBreak: "clone",
        }}
      >
        {cue.text}
      </span>
    </div>
  ) : null;
};

export const CeciliaPitch: React.FC = () => {
  useBrandFonts();
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: B.sky900 }}>
      <TransitionSeries>
        {scenes.map((scene, i) => (
          <React.Fragment key={scene.id}>
            <TransitionSeries.Sequence
              durationInFrames={scene.visualDuration}
              name={scene.chapter}
            >
              <SceneView scene={scene} />
            </TransitionSeries.Sequence>
            {i < scenes.length - 1 ? (
              <TransitionSeries.Transition
                timing={linearTiming({ durationInFrames: TRANSITION_FRAMES, easing: Easing.inOut(Easing.cubic) })}
                presentation={dissolve()}
              />
            ) : null}
          </React.Fragment>
        ))}
      </TransitionSeries>
      <Html5Audio src={staticFile("audio/continuous.m4a")} />
      <Captions />
      <AbsoluteFill
        style={{
          background: B.sky900,
          opacity: interpolate(
            f,
            [0, 6, TOTAL_FRAMES - 10, TOTAL_FRAMES - 1],
            [1, 0, 0, 1],
            clamp,
          ),
          pointerEvents: "none",
        }}
      />
    </AbsoluteFill>
  );
};
