import React from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  cancelRender,
  continueRender,
  delayRender,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
} from "remotion";

// Values from cecilai/web/src/tokens.css and landing.css. The sky gradient is the landing's only color moment.
export const B = {
  blue: "#014FFB",
  sky100: "#DCE8FF",
  sky300: "#7EA8FF",
  sky500: "#2F6BFF",
  sky900: "#0B2A93",
  ink: "#000000",
  inkApp: "#1D1C1D",
  ink70: "#000000B3",
  muted: "#616061",
  onInkMuted: "#C9C9CE",
  gray100: "#F4F4F5",
  gray200: "#E8E8EA",
  line: "#00000014",
  glassLabel: "#FFFFFFD9",
  caution: "#FFC21A",
  success: "#0E7A4B",
  sky: "linear-gradient(in oklab 160deg, oklab(73.8% -0.015 -0.134) 0%, oklab(58.1% -0.024 -0.228) 45%, oklab(47.3% -0.020 -0.222) 75%, oklab(35% -0.016 -0.173) 100%)",
};
export const F = {
  sans: '"Inter Variable", Inter, sans-serif',
  mono: '"DM Mono", monospace',
};

let fontPromise: Promise<void> | undefined;
export const useBrandFonts = () => {
  const [handle] = React.useState(() =>
    delayRender("Load Cecilia landing fonts"),
  );
  React.useEffect(() => {
    fontPromise ??= Promise.all([
      new FontFace(
        "Inter Variable",
        `url(${staticFile("fonts/inter-variable.woff2")})`,
        { weight: "100 900" },
      ).load(),
      new FontFace("DM Mono", `url(${staticFile("fonts/dm-mono.woff2")})`, {
        weight: "400",
      }).load(),
    ]).then((fonts) => {
      fonts.forEach((font) => document.fonts.add(font));
    });
    fontPromise.then(() => continueRender(handle)).catch(cancelRender);
  }, [handle]);
};

export const clamp = {
  extrapolateLeft: "clamp" as const,
  extrapolateRight: "clamp" as const,
};
export const ease = Easing.bezier(0.22, 1, 0.36, 1);
export const easeInOut = Easing.bezier(0.65, 0, 0.35, 1);
export const ramp = (f: number, from: number, length = 18) =>
  interpolate(f, [from, from + length], [0, 1], { ...clamp, easing: ease });
export const pop = (f: number, from: number, damping = 18) =>
  spring({ fps: 30, frame: f - from, config: { damping, stiffness: 140 } });

// Kinetic type: words arrive one by one out of a blur. Words wrapped in [brackets] take the accent treatment;
// a lone "/" breaks the line.
export const Kinetic: React.FC<{
  text: string;
  start?: number;
  stagger?: number;
  revealFrames?: number;
  accent?: string;
  marker?: string;
  style?: React.CSSProperties;
}> = ({
  text,
  start = 0,
  stagger = 3,
  revealFrames = 20,
  accent = B.blue,
  marker,
  style,
}) => {
  const f = useCurrentFrame();
  let inAccent = false;
  const words = text.split(" ").map((raw) => {
    const opens = raw.startsWith("[");
    if (opens) inAccent = true;
    const word = {
      t: raw.replace(/[[\]]/g, ""),
      accent: inAccent,
      last: raw.includes("]"),
    };
    if (raw.includes("]")) inAccent = false;
    return word;
  });
  return (
    <div style={style}>
      {words.map((w, i) => {
        if (w.t === "/") return <br key={i} />;
        const p = ramp(f, start + i * stagger, revealFrames);
        const markerIn = ramp(f, start + words.length * stagger + 4, 16);
        return (
          <React.Fragment key={i}>
            <span
              style={{
                display: "inline-block",
                position: "relative",
                opacity: p,
                filter: `blur(${(1 - p) * 5}px)`,
                transform: `translateY(${(1 - p) * 16}px)`,
                color: w.accent && !marker ? accent : undefined,
              }}
            >
              {w.accent && marker ? (
                <span
                  style={{
                    position: "absolute",
                    left: -6,
                    right: w.last ? -10 : -26,
                    top: "8%",
                    bottom: "2%",
                    borderRadius: 14,
                    background: marker,
                    transform: `scaleX(${markerIn})`,
                    transformOrigin: "0 50%",
                  }}
                />
              ) : null}
              <span
                style={{
                  position: "relative",
                  color: w.accent && marker ? accent : undefined,
                }}
              >
                {w.t}
              </span>
            </span>{" "}
          </React.Fragment>
        );
      })}
    </div>
  );
};

export const Rise: React.FC<
  React.PropsWithChildren<{
    at: number;
    y?: number;
    style?: React.CSSProperties;
  }>
> = ({ at, y = 22, style, children }) => {
  const f = useCurrentFrame();
  const p = ramp(f, at, 22);
  return (
    <div
      style={{
        opacity: p,
        transform: `translateY(${(1 - p) * y}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// The landing's lockup: the sky-100 avatar tile and the lowercase wordmark. It builds mark first, then the word.
export const Wordmark: React.FC<{
  size?: number;
  at?: number;
  color?: string;
  tile?: string;
}> = ({ size = 34, at = -100, color = B.ink, tile = B.sky100 }) => {
  const f = useCurrentFrame();
  const mark = pop(f, at, 14);
  const word = ramp(f, at + 8, 18);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: size * 0.38 }}>
      <div
        style={{
          width: size * 1.1,
          height: size * 1.1,
          borderRadius: size * 0.26,
          background: tile,
          overflow: "hidden",
          transform: `scale(${mark})`,
        }}
      >
        <Img
          src={staticFile("images/cecilia-avatar.png")}
          style={{ width: "100%", height: "100%", objectFit: "contain" }}
        />
      </div>
      <span
        style={{
          fontSize: size,
          fontWeight: 750,
          letterSpacing: -size * 0.03,
          color,
          clipPath: `inset(-20% ${(1 - word) * 100}% -20% 0)`,
          transform: `translateX(${(1 - word) * -14}px)`,
          display: "inline-block",
        }}
      >
        cecilai
      </span>
    </div>
  );
};

export const Eyebrow: React.FC<
  React.PropsWithChildren<{ color?: string; style?: React.CSSProperties }>
> = ({ children, color = B.blue, style }) => (
  <div
    style={{
      fontFamily: F.mono,
      fontSize: 19,
      letterSpacing: 2.2,
      textTransform: "uppercase",
      color,
      ...style,
    }}
  >
    {children}
  </div>
);

// Sky background with two slow drifting lights so the gradient never sits still.
export const Sky: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: B.sky, overflow: "hidden" }}>
      <div
        style={{
          position: "absolute",
          width: 1400,
          height: 1400,
          borderRadius: "50%",
          left: -420 + Math.sin(f / 90) * 60,
          top: -760 + Math.cos(f / 110) * 40,
          background: "radial-gradient(closest-side, #FFFFFF55, #FFFFFF00)",
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1100,
          height: 1100,
          borderRadius: "50%",
          right: -380 + Math.cos(f / 80) * 50,
          bottom: -620,
          background: "radial-gradient(closest-side, #0B2A9366, #0B2A9300)",
        }}
      />
    </AbsoluteFill>
  );
};

// A speech-bubble tile: the unit of the chat-tile charts.
export const tileRadius = (s: number) =>
  `${s * 0.32}px ${s * 0.32}px ${s * 0.32}px ${s * 0.08}px`;

// Rolling digits for counters: each digit is a column that scrolls into place.
export const Odometer: React.FC<{
  value: string;
  progress: number;
  size: number;
  color?: string;
}> = ({ value, progress, size, color }) => (
  <div
    style={{
      display: "flex",
      fontFamily: F.mono,
      fontSize: size,
      lineHeight: 1,
      height: size,
      overflow: "hidden",
      letterSpacing: -size * 0.05,
      opacity: progress > 0 ? 1 : 0,
      color,
    }}
  >
    {value.split("").map((ch, i) => {
      if (!/\d/.test(ch)) {
        return (
          <span key={i} style={{ opacity: progress > 0 ? 1 : 0 }}>
            {ch}
          </span>
        );
      }
      const target = Number(ch) + 10 * (value.length - i);
      const shown = target * Math.min(1, progress * (1 + i * 0.08));
      return (
        <span
          key={i}
          style={{ display: "inline-block", height: size, overflow: "hidden" }}
        >
          <span
            style={{
              display: "flex",
              flexDirection: "column",
              transform: `translateY(${-(shown % 10) * size}px)`,
            }}
          >
            {Array.from({ length: 11 }, (_, d) => (
              <span key={d} style={{ height: size }}>
                {d % 10}
              </span>
            ))}
          </span>
        </span>
      );
    })}
  </div>
);
