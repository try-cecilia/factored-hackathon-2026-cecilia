import { Composition } from "remotion";
import { CeciliaPitch } from "./Composition";
import { TOTAL_FRAMES } from "./timing";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="Cecilia3Minutes"
        component={CeciliaPitch}
        durationInFrames={TOTAL_FRAMES}
        fps={30}
        width={1920}
        height={1080}
      />
    </>
  );
};
