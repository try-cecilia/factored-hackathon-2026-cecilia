# /// script
# requires-python = ">=3.11"
# dependencies = ["imageio-ffmpeg"]
# ///
"""Verify the delivered duration, decodability and complete timed captions."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import imageio_ffmpeg

ROOT = Path(__file__).resolve().parents[1]
video = ROOT / "out/cecilia-3min-en.mp4"
result = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-hide_banner", "-xerror",
    "-i", str(video), "-af", "volumedetect", "-progress", "pipe:1", "-nostats", "-f", "null", "-"],
    capture_output=True, text=True, check=True)
match = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", result.stderr)
seconds = int(match[1])*3600 + int(match[2])*60 + float(match[3])
frames = int(re.findall(r"^frame=(\d+)", result.stdout, re.M)[-1])
timeline = json.loads((ROOT / "src/data/timeline.json").read_text())
expected_frames = sum(s["duration"] for s in timeline)
assert abs(seconds - expected_frames / 30) <= .01, seconds
assert frames == expected_frames, frames
assert "1920x1080" in result.stderr and "30 fps" in result.stderr
timeline = json.loads((ROOT / "src/data/timeline.json").read_text())
captions = json.loads((ROOT / "src/data/captions.json").read_text())
transition_frames = timeline[0]["visualDuration"] - timeline[0]["duration"]
assert sum(s["visualDuration"] for s in timeline) - transition_frames*(len(timeline)-1) == expected_frames
assert " ".join(c["text"] for c in captions) == " ".join(s["text"] for s in timeline)
end = 0
for cue in captions:
    assert end <= cue["start"] < cue["end"] <= seconds
    end = cue["end"]
master = json.loads((ROOT / "public/audio/continuous.json").read_text())
assert abs(master["duration"] - expected_frames/30) <= 1/30
assert len({s["audio"] for s in timeline}) == 1
assert all(s["audio"] == "audio/continuous.m4a" for s in timeline)
for segment, scene in zip(master["segments"], timeline):
    assert segment["start"] >= scene["from"]/30
    assert segment["end"] <= (scene["from"] + scene["visualDuration"])/30
assert master["text"] == " ".join(s["text"] for s in timeline)
volume = dict(re.findall(r"(mean_volume|max_volume): ([-\d.]+) dB", result.stderr))
assert float(volume["max_volume"]) < 0
report = {"verified_at": datetime.now(timezone.utc).isoformat(), "duration_seconds": frames / 30,
    "container_duration_seconds": seconds,
    "frames": frames, "transition_seconds": transition_frames / 30, "fps": 30, "width": 1920, "height": 1080, "decode": "passed",
    "captions": {"cues": len(captions), "complete_script": True, "ordered_nonoverlapping": True},
    "audio": {**volume, "playback": "single continuous master", "mastering": master["method"], "boundary_checks": json.loads((ROOT / "out/audio-boundary-check.json").read_text())}, "voice": "ElevenLabs Sarah / eleven_multilingual_v2", "scenes": len(timeline),
    "sha256": hashlib.sha256(video.read_bytes()).hexdigest(), "bytes": video.stat().st_size,
    "visual_review": "Representative scene frames inspected before render."}
(ROOT / "out/validation.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
