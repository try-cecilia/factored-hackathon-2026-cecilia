# /// script
# requires-python = ">=3.11"
# dependencies = ["imageio-ffmpeg"]
# ///
"""Prepare genuine deployed recordings and a narration-led demo timeline."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import textwrap
import imageio_ffmpeg

ROOT = Path(__file__).resolve().parents[1]
CLIPS = ROOT / "public/source-clips"
FF = imageio_ffmpeg.get_ffmpeg_exe()
FPS = 30
TRANSITION = 18


def run(args):
    p = subprocess.run([FF, "-y", "-hide_banner", *args], capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-5000:])


def duration(path):
    p = subprocess.run([FF, "-i", str(path)], capture_output=True, text=True)
    match = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", p.stderr)
    return int(match[1]) * 3600 + int(match[2]) * 60 + float(match[3])


def stamp(t):
    ms = round(t * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"


def main():
    scenes = json.loads((ROOT / "src/data/script.json").read_text())
    master = json.loads((ROOT / "public/audio/continuous.json").read_text())
    assert master["text"] == " ".join(s["text"] for s in scenes)
    audio = ROOT / "public/audio/continuous.m4a"
    assert master["audio_sha256"] == hashlib.sha256(audio.read_bytes()).hexdigest()
    alignment = master["alignment"]
    # Visual changes anticipate the next sentence; audio never restarts with a slide.
    starts = [0] + [round((seg["start"] - .25) * FPS) for seg in master["segments"][1:]]
    expected_frames = round(master["duration"] * FPS)
    timeline = []
    captions = []
    for i, scene in enumerate(scenes):
        seg = master["segments"][i]
        cursor = starts[i]
        end = starts[i+1] if i+1 < len(starts) else expected_frames
        used = 0
        for sentence in re.split(r"(?<=[.!?])\s+", scene["text"]):
            for phrase in textwrap.wrap(sentence, width=76, break_long_words=False, break_on_hyphens=False):
                pos = scene["text"].index(phrase, used)
                used = pos + len(phrase)
                start = alignment["character_start_times_seconds"][seg["characterStart"] + pos]
                finish = alignment["character_end_times_seconds"][seg["characterStart"] + used - 1]
                captions.append({"start": start, "end": finish, "text": phrase})
        timeline.append({**scene, "seconds": (end-cursor)/FPS, "from": cursor, "duration": end-cursor,
            "visualDuration": end-cursor + (TRANSITION if i < len(scenes)-1 else 0),
            "audio": "audio/continuous.m4a", "audioOffset": round(seg["start"]*FPS)-cursor,
            "spokenSeconds": seg["end"]-seg["start"], "characterStart": seg["characterStart"]})
    cursor = expected_frames
    take = master

    # Native-resolution Chrome recordings. Trim waits without changing action order.
    edits = {
        "balance": [("01-balance.mp4", 3.69, 15.79)],
        "trace": [("03-trace.mp4", 0, 14.5), ("03-bank-trace.mp4", 0, 3.9)],
        "portuguese": [("04-portuguese.mp4", 0, 9.1)],
        "handoff": [("05-handoff.mp4", 0, 17.1)],
        "safety": [("06-injection.mp4", 0, 6.5), ("07-outage.mp4", 0, 9.0)],
    }
    provenance = []
    for name, ranges in edits.items():
        scene = next(s for s in timeline if s["id"] == name)
        inputs = []
        filters = []
        for i, (filename, start, end) in enumerate(ranges):
            source = CLIPS / filename
            inputs.extend(["-i", str(source)])
            filters.append(f"[{i}:v]trim=start={start}:end={end},setpts=PTS-STARTPTS,fps=30,scale=3840:2400:flags=lanczos,setsar=1[v{i}]")
            provenance.append({"scene": name, "source": filename, "start": start, "end": end,
                               "sha256": hashlib.sha256(source.read_bytes()).hexdigest()})
        if len(ranges) == 1:
            filters.append("[v0]tpad=stop_mode=clone:stop_duration=30[out]")
        else:
            offset = ranges[0][2] - ranges[0][1] - .4
            filters.append(f"[v0][v1]xfade=transition=fade:duration=0.4:offset={offset},tpad=stop_mode=clone:stop_duration=30[out]")
        target = ROOT / "public/clips" / f"{name}.mp4"
        run([*inputs, "-filter_complex", ";".join(filters), "-map", "[out]", "-an",
             "-t", str(scene["visualDuration"] / FPS), "-c:v", "libx264", "-preset", "fast", "-crf", "12",
             "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(target)])
        print(f'{name}: {scene["visualDuration"] / FPS:.1f}s prepared', flush=True)
    (ROOT / "src/data/timeline.json").write_text(json.dumps(timeline, indent=2) + "\n")
    (ROOT / "src/data/captions.json").write_text(json.dumps(captions, indent=2) + "\n")
    (ROOT / "out/cecilia-3min-en.srt").write_text("\n\n".join(
        f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(captions)) + "\n")
    (ROOT / "public/provenance.json").write_text(json.dumps({
        "app": "https://cecil-ai.onrender.com", "captured_on": "2026-10-04",
        "source_package": "public/source-clips/chrome-capture.json", "duration_seconds": cursor / FPS, "transition_seconds": TRANSITION / FPS,
        "voice": take["voice"], "voice_settings": take["voice_settings"], "narration": {"method": master["method"], "sha256": master["audio_sha256"], "asset": "audio/continuous.m4a"},
        "edits": provenance,
        "brand_source": {"url": "https://cecil-ai.onrender.com/", "tokens": "cecilai/web/src/tokens.css", "layout": "cecilai/web/src/landing/landing.css", "fonts": ["Inter Variable", "DM Mono"], "primary_color": "#014FFB", "mascot": "cecilai/web/public/cecilia-hero.png"},
        "motion_reference_only": "https://www.youtube.com/watch?v=2t495uAfTak",
        "treatment": "V10: production checklist removed; added measured 26.9-point resolution lift, 171/171 complete handoffs and 1.43s/2.99s evaluation case latency from SYSTEM_EVAL_LIVE.md run 1. New Sarah narration for results and closing joins the continuous master. Visuals dissolve over uninterrupted audio with 0.6-second eased overlaps, gentle camera motion, and 0.4-second dissolves between app views. No large flying headlines, full-screen frosted scrims, window zoom kicks or square spotlights. Native 3840x2400 Chrome footage retained. Source wait trims and held frames do not measure service latency.",
        "metrics_sources": json.loads((ROOT / "public/results-sources.json").read_text()),
        "capture": json.loads((ROOT / "public/source-clips/chrome-capture.json").read_text()),
        "public_repository": None}, indent=2) + "\n")
    print(f"Ready: {cursor / FPS:g} seconds, {len(captions)} aligned caption cues.")


if __name__ == "__main__":
    main()
