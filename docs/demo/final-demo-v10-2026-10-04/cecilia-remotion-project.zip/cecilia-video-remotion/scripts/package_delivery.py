"""Package source and verified render; deliberately excludes secrets and references."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[1]
delivery = root.parent / 'cecilai/docs/demo/final-demo-v10-2026-10-04'
delivery.mkdir(parents=True, exist_ok=True)
validation = json.loads((root / 'out/validation.json').read_text())
video = root / 'out/cecilia-3min-en.mp4'
assert validation['sha256'] == hashlib.sha256(video.read_bytes()).hexdigest()
assert validation['duration_seconds'] == sum(s['duration'] for s in json.loads((root / 'src/data/timeline.json').read_text())) / 30
for name in ['cecilia-3min-en.mp4', 'cecilia-3min-en.m4a', 'cecilia-3min-en.srt', 'validation.json', 'audio-boundary-check.json']:
    shutil.copy2(root / 'out' / name, delivery / name)
for name in ['script.json', 'timeline.json', 'captions.json']:
    shutil.copy2(root / 'src/data' / name, delivery / name)
shutil.copy2(root / 'public/provenance.json', delivery / 'provenance.json')
allowed = ['src', 'scripts', 'public', 'package.json', 'package-lock.json', 'remotion.config.ts',
           'tsconfig.json', 'eslint.config.mjs', '.prettierrc', '.gitignore', 'README.md']
files = []
for entry in allowed:
    item = root / entry
    files.extend([item] if item.is_file() else [f for f in item.rglob('*') if f.is_file()
                 and '__pycache__' not in f.parts and f.suffix != '.pyc' and f.name not in {'.DS_Store', '.env'}])
archive_path = delivery / 'cecilia-remotion-project.zip'
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for file in files:
        archive.write(file, Path('cecilia-video-remotion') / file.relative_to(root))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert not any('/.reference/' in n or n.endswith('/.env') or '/node_modules/' in n for n in archive.namelist())
manifest = {'created_at': datetime.now(timezone.utc).isoformat(), 'duration_seconds': validation['duration_seconds'],
    'revision': 'v10 removes the production checklist, adds measured resolution lift, handoff completeness and evaluation latency, and preserves continuous mastered audio and gentle motion', 'public_repository_url': None,
    'files': [{'path': f.name, 'bytes': f.stat().st_size, 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()}
              for f in sorted(delivery.iterdir()) if f.is_file() and f.name != 'artifact-manifest.json']}
(delivery / 'artifact-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'Packaged {len(files)} source files and {len(manifest["files"])} delivery files: {delivery}')
