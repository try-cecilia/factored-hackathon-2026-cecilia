# /// script
# requires-python = ">=3.11"
# dependencies = ["python-dotenv"]
# ///
"""Generate/cache ElevenLabs speech and character timing for the pitch.

uv run scripts/generate_narration.py
Reads ELEVENLABS_API_KEY from environment, local .env or the Cecilia source .env.
Unchanged takes are reused without API calls. No automatic paid-request retries.
"""
import base64
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import urllib.error
import urllib.request

from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public"
VOICE = {"provider": "ElevenLabs", "name": "Sarah", "voice_id": "EXAVITQu4vr4xnSDxMaL",
         "model_id": "eleven_multilingual_v2", "language": "en", "synthetic": True}
SETTINGS = {"stability": 0.6, "similarity_boost": 0.75, "style": 0.15,
            "use_speaker_boost": True, "speed": 1.0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--only', help='Generate or refresh a single scene ID')
    args = parser.parse_args()
    segments = json.loads((ROOT / "src/data/script.json").read_text())
    target = OUT / "audio"
    target.mkdir(exist_ok=True)
    source = Path(os.environ.get("CECILIA_SOURCE_DIR", str(ROOT.parent / "cecilai")))
    key = (os.environ.get("ELEVENLABS_API_KEY") or dotenv_values(ROOT / ".env").get("ELEVENLABS_API_KEY")
           or dotenv_values(source / ".env").get("ELEVENLABS_API_KEY"))
    for index, segment in enumerate(segments):
        if args.only and segment['id'] != args.only:
            continue
        payload = {"text": segment["text"], "model_id": VOICE["model_id"],
                   "language_code": "en", "voice_settings": SETTINGS}
        if index:
            payload["previous_text"] = segments[index - 1]["text"]
        if index + 1 < len(segments):
            payload["next_text"] = segments[index + 1]["text"]
        fingerprint = hashlib.sha256(json.dumps({"voice": VOICE, "payload": payload}, sort_keys=True).encode()).hexdigest()
        name = f'{index + 1:02}-{segment["id"]}'
        meta = target / f"{name}.json"
        audio = target / f"{name}.mp3"
        if meta.exists() and audio.exists():
            cached = json.loads(meta.read_text())
            if cached.get("request_sha256") == fingerprint and cached.get("audio_sha256") == hashlib.sha256(audio.read_bytes()).hexdigest():
                print(f"{name}: reused", flush=True)
                continue
        if not key:
            raise SystemExit("ELEVENLABS_API_KEY is required for new takes.")
        req = urllib.request.Request(
            f'https://api.elevenlabs.io/v1/text-to-speech/{VOICE["voice_id"]}/with-timestamps?output_format=mp3_44100_128',
            data=json.dumps(payload).encode(),
            headers={"xi-api-key": key, "Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=180) as response:
                result = json.load(response)
                request_id = response.headers.get("request-id")
        except urllib.error.HTTPError as error:
            # Provider error bodies contain no request headers, but redact defensively.
            message = error.read().decode().replace(key, "[redacted]")
            raise SystemExit(f"ElevenLabs HTTP {error.code}: {message[:1000]}") from None
        data = base64.b64decode(result["audio_base64"], validate=True)
        alignment = result["alignment"]
        if "".join(alignment["characters"]) != segment["text"]:
            raise SystemExit(f"Unexpected alignment text for {name}; take not saved.")
        audio.write_bytes(data)
        meta.write_text(json.dumps({"voice": VOICE, "voice_settings": SETTINGS,
            "request_sha256": fingerprint, "audio_sha256": hashlib.sha256(data).hexdigest(),
            "created_at": datetime.now(timezone.utc).isoformat(), "request_id": request_id,
            "text": segment["text"], "alignment": alignment}, indent=2) + "\n")
        print(f'{name}: generated, {alignment["character_end_times_seconds"][-1]:.1f}s', flush=True)


if __name__ == "__main__":
    main()
