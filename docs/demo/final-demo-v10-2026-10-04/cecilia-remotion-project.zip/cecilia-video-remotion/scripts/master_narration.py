# /// script
# requires-python = ">=3.11"
# dependencies = ["imageio-ffmpeg"]
# ///
"""Assemble complete cached takes into one level-matched, uncut playback asset.

Preserves complete scene recordings, joins padded silence, and applies one final
loudness pass. Voice playback is independent of visual scene boundaries.
"""
from pathlib import Path
import hashlib, json, math, re, subprocess, wave
import imageio_ffmpeg
ROOT = Path(__file__).resolve().parents[1]
FF = imageio_ffmpeg.get_ffmpeg_exe()
SR = 48000

def run(args):
    return subprocess.run([FF, '-y', '-hide_banner', *args], capture_output=True, check=True)

def main():
    scenes = json.loads((ROOT/'src/data/script.json').read_text())
    work = ROOT/'out/audio-master'; work.mkdir(exist_ok=True)
    source = ROOT/'public/audio'
    cursor = .12
    sources=[]; align={'characters':[], 'character_start_times_seconds':[], 'character_end_times_seconds':[]}
    segments=[]; parts=[]
    # A short pause separates thoughts. Crossfades run entirely inside padding.
    pause=.16; overlap=.04
    for i, s in enumerate(scenes):
        stem=f'{i+1:02}-{s["id"]}'; mp3=source/f'{stem}.mp3'
        meta=json.loads(mp3.with_suffix('.json').read_text())
        assert meta['text']==s['text']
        assert hashlib.sha256(mp3.read_bytes()).hexdigest()==meta['audio_sha256']
        measured=run(['-i',str(mp3),'-af','loudnorm=I=-18:TP=-2:LRA=7:print_format=json','-f','null','-']).stderr.decode()
        levels=json.loads(re.search(r'\{\s*"input_i".*?\}',measured,re.S)[0])
        gain=-19-float(levels['input_i'])
        wav=work/f'{stem}.wav'
        # Constant gain keeps each take's natural dynamics; tiny edge ramps only prevent clicks.
        run(['-i',str(mp3),'-af',f'volume={gain}dB','-ar',str(SR),'-ac','1','-c:a','pcm_s16le',str(wav)])
        with wave.open(str(wav)) as w: dur=w.getnframes()/SR
        if i:
            align['characters'].append(' ')
            align['character_start_times_seconds'].append(cursor-pause)
            align['character_end_times_seconds'].append(cursor)
        char_start=len(align['characters'])
        for key, vals in meta['alignment'].items():
            align[key].extend(vals if key=='characters' else [v+cursor for v in vals])
        segments.append({'id':s['id'],'start':cursor,'end':cursor+dur,'characterStart':char_start})
        sources.append({'file':mp3.name,'sha256':meta['audio_sha256'],'gain_db':gain,'complete_take_seconds':dur})
        # Tiny anti-click ramps preserve the full take duration.
        padded=work/f'{stem}-padded.wav'
        head=.12 if i==0 else overlap
        tail=2.0 if i==len(scenes)-1 else pause
        run(['-i',str(wav),'-af',f'afade=t=in:d=0.005,afade=t=out:st={dur-.012}:d=0.012,adelay={head*1000}:all=1,apad=pad_dur={tail}',str(padded)])
        parts.append(padded)
        cursor += dur+pause
    inputs=[]; filters=[]
    for p in parts: inputs.extend(['-i',str(p)])
    last='0:a'
    for i in range(1,len(parts)):
        out=f'join{i}'; filters.append(f'[{last}][{i}:a]acrossfade=d={overlap}:c1=qsin:c2=qsin[{out}]');last=out
    filters.append(f'[{last}]loudnorm=I=-18:TP=-2:LRA=9,aresample=48000[out]')
    master=source/'continuous.m4a'
    run([*inputs,'-filter_complex',';'.join(filters),'-map','[out]','-c:a','aac','-b:a','192k',str(master)])
    duration=segments[-1]['end']+2.0
    payload={'voice':meta['voice'],'voice_settings':meta['voice_settings'], 'text':' '.join(s['text'] for s in scenes),'alignment':align,'segments':segments,'duration':duration,'audio_sha256':hashlib.sha256(master.read_bytes()).hexdigest(),'method':'Complete Sarah takes including new V10 results and closing recordings, constant per-take gain, 40ms crossfades in silence padding, one global loudness master; single uninterrupted playback asset.', 'source_takes':sources}
    (source/'continuous.json').write_text(json.dumps(payload,indent=2)+'\n')
    detected=run(['-i',str(master),'-af','silencedetect=noise=-42dB:d=0.05','-f','null','-']).stderr.decode()
    spans=[]; start=None
    for line in detected.splitlines():
        if 'silence_start:' in line: start=float(line.split('silence_start:')[1].strip())
        if 'silence_end:' in line and start is not None:
            end=float(line.split('silence_end:')[1].split('|')[0].strip())
            spans.append((start,end)); start=None
    checks=[]
    for a,b in zip(segments,segments[1:]):
        nearby=[(x,y) for x,y in spans if x<b['start']+.10 and y>a['end']-.10]
        longest=max((y-x for x,y in nearby),default=0)
        assert longest<.5, (a['id'],b['id'],longest)
        checks.append({'from':a['id'],'to':b['id'],'longest_silence_seconds':round(longest,4),'full_previous_take_preserved':True,'voice_overlap':False})
    (ROOT/'out/audio-boundary-check.json').write_text(json.dumps({'method':'FFmpeg silence detection at -42 dB, minimum 50 ms; all joins under 500 ms; full source take lengths retained','boundaries':checks},indent=2)+'\n')
    print(json.dumps({'duration':duration,'segments':segments},indent=2))
if __name__=='__main__':main()
