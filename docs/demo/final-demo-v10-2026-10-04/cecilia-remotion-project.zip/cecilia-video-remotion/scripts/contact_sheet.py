# /// script
# requires-python = ">=3.11"
# dependencies = ["pillow"]
# ///
"""Tile out/stills/*.png into a labelled contact sheet: uv run scripts/contact_sheet.py [out.jpg] [glob]"""
import sys
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
target = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "out/contact-v5.jpg"
files = sorted((ROOT / "out/stills").glob(sys.argv[2] if len(sys.argv) > 2 else "*.png"))
W, H, COLS, LABEL = 640, 360, 4, 26
rows = -(-len(files) // COLS)
sheet = Image.new("RGB", (W * COLS, (H + LABEL) * rows), "white")
draw = ImageDraw.Draw(sheet)
for i, f in enumerate(files):
    x, y = (i % COLS) * W, (i // COLS) * (H + LABEL)
    draw.text((x + 8, y + 6), f.stem, fill="black")
    sheet.paste(Image.open(f).convert("RGB").resize((W, H)), (x, y + LABEL))
sheet.save(target, quality=85)
print(target, len(files))
