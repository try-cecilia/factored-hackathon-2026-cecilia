import {
  openBrowser,
  selectComposition,
  renderStill,
} from "@remotion/renderer";
import { mkdirSync, readFileSync } from "node:fs";
import path from "node:path";

// Renders three moments per scene and every scene boundary, for a contact sheet review.
// Usage: node scripts/preview.mjs [sceneId ...]
const serveUrl = path.resolve("build");
const only = process.argv.slice(2);
const out = "out/stills";
mkdirSync(out, { recursive: true });
const timeline = JSON.parse(readFileSync("src/data/timeline.json", "utf8"));
const jobs = [];
timeline.forEach((s, i) => {
  if (only.length && !only.includes(s.id)) return;
  for (const at of [0.08, 0.45, 0.85]) {
    const frame = s.from + Math.round(s.duration * at);
    jobs.push({ frame, name: `${String(i + 1).padStart(2, "0")}-${s.id}-${String(frame).padStart(4, "0")}` });
  }
  if (i && !only.length) {
    jobs.push({ frame: s.from + 2, name: `${String(i + 1).padStart(2, "0")}-${s.id}-cut` });
  }
});
const browser = await openBrowser("chrome");
try {
  const composition = await selectComposition({ serveUrl, id: "Cecilia3Minutes", puppeteerInstance: browser });
  for (let i = 0; i < jobs.length; i += 4) {
    await Promise.all(
      jobs.slice(i, i + 4).map(async ({ frame, name }) => {
        await renderStill({
          serveUrl,
          composition,
          puppeteerInstance: browser,
          frame,
          output: `${out}/${name}.png`,
          logLevel: "error",
        });
        console.log(`${name}: frame ${frame}`);
      }),
    );
  }
} finally {
  await browser.close({ silent: true });
}
