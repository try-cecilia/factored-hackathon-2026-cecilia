# Cecilia · narrated demo

Editable Remotion project created with `npx create-video@latest --yes --blank --no-tailwind cecilia-video-remotion`.
The current composition is **2:43.2** (163.2 seconds), 4,896 frames at 30 fps, 1920 × 1080.
Eased dissolves last 0.6 seconds and overlap the narration without adding inter-slide gaps. The narration opens with customer value, then uses the numbers to support it.
English narration uses ElevenLabs Sarah. The app footage is Spanish and Portuguese, recorded from the deployed demo on 4 October 2026.

This revision follows the [Cecilia landing page](https://cecil-ai.onrender.com/): white layouts, Cecilia blue (`#014FFB`), Inter Variable headings and body, DM Mono labels and figures, the original mascot and lowercase wordmark, a sky-gradient hero, neutral process cards, and a black results section.
The exact fonts and mascot assets are bundled locally. The renderer waits for both fonts before drawing frames.
V8 replaces all app footage with native 3840 × 2400 captures from Google Chrome on the deployed app. The 1920 × 1200 CSS viewport is captured at device scale 2 using lossless PNG frames at up to 8.3 fps, then encoded at 30 fps with repeated frames between captures. Direct video sizing avoids an extra scaled camera layer. V10 retains the opening and demo story and uses one continuous audio master assembled from the complete Sarah recordings. Camera moves ease over about two seconds. Large flying headings, frosted full-screen flashes and entry zoom kicks have been removed. Spotlight rectangles, dimming masks and floating callout cards have been removed. The model and bank-data lanes, contact chart, results grid, and circular closing reveal are original Cecilia displays. The reference video informs motion and pacing only.

The opening sentence states both the purpose and audience: "Cecilia answers account and payment questions for Spanish- and Portuguese-speaking bank customers, straight from verified bank data."

## Open and render

```sh
npm ci
npm run dev -- --port=3010
npm run render
```

Open `http://localhost:3010/Cecilia3Minutes`. Select the composition to scrub its timeline, preview the scenes and render.
The output is `out/cecilia-3min-en.mp4`. Rendering uses the included audio and footage and does not call ElevenLabs.

## Edit

- `src/Composition.tsx`: composition, transitions, narration and captions.
- `src/scenes.tsx`: opening, contact chart, model/data diagram, results and closing.
- `src/demo.tsx`: product window, camera movements, direct camera framing.
- `src/brand.tsx`: Cecilia tokens, fonts, wordmark, kinetic type and shared motion.
- `src/cues.ts`: visual cues derived from narration character alignment.
- `src/data/script.json`: the eleven scenes, approved spoken text and titles. Legacy scene lengths are editorial references; the generated timeline follows the audio master.
- `src/data/timeline.json`: generated visual frame positions, word-alignment indices and clip assignments.
- `src/data/captions.json`: generated phrase captions with ElevenLabs character timing.
- `public/audio/`: original MP3 takes plus `continuous.m4a` and its combined character alignment.
- `public/source-clips/`: the original deployed-app recordings used in this edit.
- `public/clips/`: prepared footage with cuts and held final frames. The app is never recreated or generated.
- `public/images/cecilia-hero.png`: the original landing-page mascot used in the opening.
- `public/fonts/`: Inter Variable and DM Mono, with their license files.
- `public/images/demo-qr.png`: QR for `https://cecil-ai.onrender.com`.
- `scripts/prepare_assets.py`: source ranges, visual placement and caption preparation.
- `scripts/master_narration.py`: constant gain matching, complete-take assembly and global loudness mastering.

After editing spoken text or timing:

```sh
npm run voice
npm run prepare
npm run lint
npm run stills
npm run render
uv run scripts/verify_video.py
```

New voice takes require `ELEVENLABS_API_KEY` in the environment or local `.env`. On the original workstation, the generator also reads the sibling `cecilai/.env`. It never copies the key. Unchanged takes are cached; generating changed takes uses ElevenLabs credits. `uv` resolves the declared Python dependencies.
The existing recordings are cached. `npm run prepare` assembles them into a single audio track and prepares the visual timeline. V10 adds newly generated Sarah recordings for the results expansion and closing. The production-readiness checklist and its narration have been removed. The new results show the 26.9 percentage-point gain over keywords, 171 complete handoffs out of 171, and end-to-end evaluation case times of 1.43 seconds at the median and 2.99 seconds at the 95th percentile. The live-model report is the source, using Sonnet 5 run 1. The latency is from the synthetic evaluation, not a deployed-app measurement. Source details are in `public/results-sources.json` and `public/provenance.json`.

Complete recordings are level-matched with constant gain, joined with 40 ms crossfades inside padded silence, then normalized together. The 160 ms inter-take spacing preserves short sentence pauses. No words are removed or overlapped. Regenerating speech requires ElevenLabs credits; rendering does not.

One audio element plays from beginning to end. Visual dissolves overlap 18 frames and begin 250 ms before the next paragraph, so narration is independent of slide changes. App view changes use 400 ms dissolves. Captions and animated details follow the original word timestamps shifted into the master timeline. The total duration follows that track, with a short closing tail.

## Edit structure

| Start | Scene | Duration |
|---|---|---|
| 0:00.0 | Cecilia | 16.80 s |
| 0:16.8 | Why it matters | 11.77 s |
| 0:28.6 | How it stays honest | 14.57 s |
| 0:43.1 | Español · Balance | 11.80 s |
| 0:54.9 | Português · Card payments | 8.43 s |
| 1:03.4 | Español · Pending transfer | 18.07 s |
| 1:21.4 | Human handoff | 17.90 s |
| 1:39.3 | Privacy + fallback | 15.17 s |
| 1:54.5 | Measured | 23.20 s |
| 2:17.7 | What the results mean | 16.97 s |
| 2:34.7 | Try Cecilia | 8.53 s |

## Evidence

The recordings come from `https://cecil-ai.onrender.com`. The contact chart and evaluation tiles show aggregate counts; tile placement is illustrative, not an ordering of individual case records. Recording hashes and source edit ranges are in `public/provenance.json`; native capture details are in `public/source-clips/chrome-capture.json`.
The final presentation, deployment check and video validation live in `cecilai/docs/demo/final-demo-v10-2026-10-04/`.
Baseline figures come from `docs/evidence/baseline_metrics.md`; evaluation figures come from the committed October 4 reports in `eval/reports/`.

Cuts remove waits and final frames are held where needed. The edit does not measure service latency. The outage is deliberately simulated and labeled. All customer data is synthetic. The public repository URL remains pending; no private URL is included.

Only the approved final delivery is retained in the repository. The six-slide presentation is included alongside the final video. The original MP3 takes are inputs required to reproduce the continuous narration master, not earlier video versions.
